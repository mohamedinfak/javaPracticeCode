class Employee
{
private int emp_num;
private String name;
private double sal;
Employee(int e_n, String na, double sa) //Constructor
{
emp_num=e_n;
name=na;
sal=sa;
}
public void setEmpNum(int num)
{
emp_num=num;
}
public void setName(String na)
{
name=na;
}
public void setSal(double sa)
{
sal=sa;
}
public int getEmpNum()
{
return emp_num;
}
public String getName()
{
return name;
}
public double getSal()
{
return sal;
}
}
public class ClassTest5
{
public static void main (String[] args)


{
Employee e1 = new Employee(1000,"Hary",19450);
Employee e2 = new Employee(1001,"Kalai",12400);
e2.setName("Kavi");
System.out.println ("Number\t\tName\t\tSalary");
System.out.println ("______\t\t____\t\t______");
System.out.println (e1.getEmpNum() + "\t\t" + e1.getName() + "\t\t" + e1.getSal());
System.out.println (e2.getEmpNum() + "\t\t" + e2.getName() + "\t\t" + e2.getSal());
}
}