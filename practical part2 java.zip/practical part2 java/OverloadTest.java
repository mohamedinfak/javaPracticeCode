public class OverloadTest
{
public static void main(String[] args)
{
int month=10, day=15, year=2005;
overloadDate();
overloadDate(month,day);
}
public static void overloadDate()
{
System.out.println("Date: " + "1/1/2000");
}
public static void overloadDate(int mm)
{
System.out.println("Date: " + mm + "/1/2000");
}
public static void overloadDate(int mm, int dd)
{
System.out.println("Date: " + mm + "/" + dd +"/2000");
}
public static void overloadDate(int mm, int dd, int yy)
{
System.out.println("Date: " + mm + "/" + dd +"/" + yy);
}
}
