class Point
{
private static int noOfPoints=0; //class variable
private int x; //instance variable
private int y;
Point()
{
x=0; y=0; noOfPoints++;
}
Point(int a)
{
x=a; y=a; noOfPoints++;
}
Point(int x_in, int y_in)
{
x=x_in; y=y_in; noOfPoints++;
}
public void setXY(int x_in, int y_in) //instance method
{
x=x_in; y=y_in;
}
public static int getNoOfPoints() //class method
{
return noOfPoints;
}
public int getX()
{
return x;
}
public int getY()
{
return y;
}
}
public class ClassVarTest
{
public static void main(String[] args)
{
Point p1 = new Point();
Point p2 = new Point();

p2.setXY(1,2);
System.out.println("p1 = (" + p1.getX() + "," + p1.getY() + ")");
System.out.println("p2 = (" + p2.getX() + "," + p2.getY() + ")");
System.out.println("The number of points created still now: " + p1.getNoOfPoints());
Point p3 = new Point(10); Point p4 = new Point(20,30);
System.out.println("p3 = (" + p3.getX() + "," + p3.getY() + ")");
System.out.println("p4 = (" + p4.getX() + "," + p4.getY() + ")");
System.out.println("The total number of points: " + Point.getNoOfPoints());
}
}