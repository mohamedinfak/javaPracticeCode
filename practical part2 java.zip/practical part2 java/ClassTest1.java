class Point
{
private int x;
private int y;
public void setX(int x_in)
{
x=x_in;
}
public void setY(int y_in)
{
y=y_in;
}
public int getX()
{
return x;
}
public int getY()
{
return y;
}
}
public class ClassTest1
{
public static void main (String[] args)
{
Point p1 = new Point();
Point p2 = new Point();
Point p3 = new Point();
p1.setX(10); p1.setY(10);
p2.setX(15); p2.setY(25);
p3.setX(15); p3.setY(30);
System.out.println ("The coordinate of the point 'p1': (" + p1.getX() + "," + p1.getY() + ").");
System.out.println ("The coordinate of the point 'p2': (" + p2.getX() + "," + p2.getY() + ").");
System.out.println ("The coordinate of the point 'p3': (" + p3.getX() + "," + p3.getY() + ").");
}
}