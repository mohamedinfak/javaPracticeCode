class Point
{
private int x;
private int y;
Point(int x_in, int y_in) //Constructor with arguments
{
x=x_in;


y=y_in;
}
public void setX(int x_in)
{
x=x_in;
}
public void setY(int y_in)
{
y=y_in;
}
public int getX()
{
return x;
}
public int getY()
{
return y;
}
}
public class ClassTest3
{
public static void main (String[] args)
{
Point p1 = new Point(0,0); Point p2 = new Point(10,20);
p1.setX(15);
System.out.println ("The coordinate of the point 'p1': (" + p1.getX() + "," + p1.getY() + ").");
System.out.println ("The coordinate of the point 'p2': (" + p2.getX() + "," + p2.getY() + ").");
}
}