import javax.swing.*;
class Point
{
private int x;
private int y;
Point(int x_in, int y_in) //Constructor with arguments
{
x=x_in; y=y_in;
}
public void setX(int x_in)
{
x=x_in;
}
public void setY(int y_in)
{
y=y_in;
}
public int getX()
{
return x;
}
public int getY()
{
return y;
}
}
public class ObjectArray
{
public static void main (String[] args)
{
final int N=5;
int i, x, y;
Point[] pts=new Point[N];
for (i=0; i<N; i++)
{
x=Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the x coordinate forthe point" + (i+1)));
y=Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the y coordinate forthe point" + (i+1)));
pts[i]=new Point(x,y);
}
pts[0].setX(15); pts[0].setY(10);

for (i=0; i<N; i++)
System.out.println ("The coordinate of the point" + (i+1) + ": (" + pts[i].getX() +
"," + pts[i].getY() + ").");
System.exit(0);
}
}